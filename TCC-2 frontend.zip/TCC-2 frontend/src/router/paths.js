import Modelagem from '../components/Modelagem.vue'

export default [{
        path: '/',
        name: 'Home',
        component: Modelagem
    },

    {
        path: '/Export',
        name: 'Exportar'
    },


];