<template>
  <div id="app">
    <modelagem />
  </div>
</template>

<script>
import Modelagem from "./components/Modelagem.vue";

export default {
  name: "app",
  components: {
    Modelagem,
  },
};
</script>

<style>
</style>
